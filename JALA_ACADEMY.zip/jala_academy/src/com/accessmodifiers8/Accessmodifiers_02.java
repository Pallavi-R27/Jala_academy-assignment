package com.accessmodifiers8;
/*Create a class with DEFAULT fields and methods. Access these fields 
and methods from any other class in the same package*/

public class Accessmodifiers_02 {
	//creating defualt fields
	int num=23;
	String name="Tom";
	void method2() {
		System.out.println("hello default method");
	}

	public static void main(String[] args) {
		//here we can access the defualt modifier in another class within 
		//the same package (Accessmodifier_02).
		Accessmodifiers_02 a1=new Accessmodifiers_02();
		System.out.println(a1.num);
		System.out.println(a1.name);
		a1.method2();
		

	}

}
