package com.accessmodifiers8;
/*3.Create a class with PROTECTED fields and methods.Access these 
 fields and methods from any other class in the same package.Also, Access
 the PROTECTED fields and methods from child class located in a different 
package Access the PROTECTED fields and methods from any class in 
different package.*/

public class Accessmodifiers_03 {
	//creating protected fileds.
	protected int num=57;
	protected String name="hello";
	//creating protected method.
	protected void method2() {
		System.out.println("Hello protected modifier");
	}
//here another class is accessing in Accessmodifier_02
//here protected fields and methods cann access to another package by
	//by extend and child and importing(Accessmodifier_003) 
	public static void main(String[] args) {
		Accessmodifiers_03 b1=new Accessmodifiers_03();
		System.out.println("protected filed:"+b1.num);
		System.out.println("protected filed:"+b1.name);
		b1.method2();
		
		}

}
