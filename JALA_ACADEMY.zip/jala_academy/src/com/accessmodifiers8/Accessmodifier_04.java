package com.accessmodifiers8;

public class Accessmodifier_04 {

	public static void main(String[] args) {
		//accessing public modifier in another class.
				Accessmodifiers_04 d1=new Accessmodifiers_04();
				System.out.println("printing fields:"+d1.id);
				System.out.println("printing fields:"+d1.id_name);
				d1.method3();

	}

}
