package com.accessmodifiers8;

public class Accessmodifier_02 {

	public static void main(String[] args) {
		Accessmodifiers_02 a1=new Accessmodifiers_02();
		System.out.println(a1.num);
		System.out.println(a1.name);
		a1.method2();
//accessing the protected fileds and methods from Accessmodifiers_03		
		Accessmodifiers_03 b1=new Accessmodifiers_03();
		System.out.println("protected filed:"+b1.num);
		System.out.println("protected filed:"+b1.name);
		b1.method2();

	}

}
