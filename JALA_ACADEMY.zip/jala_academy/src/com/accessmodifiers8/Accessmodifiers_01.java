package com.accessmodifiers8;
/*1. Create a class with PRIVATE fields, private method and a main method. 
Print the fields in main method. Call the private method in main method. 
Create a sub class and try to access the private fields and 
methods from sub class. */

public class Accessmodifiers_01 {
	//creating private fields
	private int num=12;
	private String name="jersey";
	//creating private instance method.
	private void method() {
		System.out.println("hello private modifier");
	}

	public static void main(String[] args) {
		Accessmodifiers_01 s1=new Accessmodifiers_01();
		System.out.println("printing private variable:"+s1.num);
		System.out.println("printing private variable:"+s1.name);
		s1.method();

	}

}
