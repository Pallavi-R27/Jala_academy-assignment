package com.accessmodifiers8;
/*4. Create a class with PUBLIC fields and methods.  
Access the public methods and fields from any class in the 
same package or different package.*/

public class Accessmodifiers_04 {
	//creating public fields
	public static int id=12;
	public static String id_name="virat";
	//creating public method
	public void method3() {
		System.out.println("hello public modifier");
	}
	public static void main(String[] args) {
		//accessing public modifier.
		Accessmodifiers_04 d1=new Accessmodifiers_04();
		System.out.println("printing fields:"+d1.id);
		System.out.println("printing fields:"+d1.id_name);
		d1.method3();
		//and here accessed in another class (Accessmodifier_04).
		//here accessed in another package  com.accessmodifier_08.
		//public can access in whole project
	}

}
