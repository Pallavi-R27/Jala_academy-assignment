package com.constructors12;
//3. Apply private, public, protected and default access modifiers to the constructor.
/*Public: Accessible from anywhere.
Protected: Accessible within the same package and by subclasses.
Default (Package-Private): Accessible only within the same package.
Private: Accessible only within the same class.*/

public class Const_JA_03 {
	 private String name;
	    private int age;

	    // Public constructor
	    public Const_JA_03() {
	        this.name = "Public";
	        this.age = 0;
	        System.out.println("Public constructor called: Name = " + this.name + ", Age = " + this.age);
	    }

	    // Protected constructor
	    protected Const_JA_03(String name) {
	        this.name = name;
	        this.age = 0;
	        System.out.println("Protected constructor called: Name = " + this.name + ", Age = " + this.age);
	    }
	 // Default (package-private) constructor
	    Const_JA_03(String name, int age) {
	        this.name = name;
	        this.age = age;
	        System.out.println("Default constructor called: Name = " + this.name + ", Age = " + this.age);
	    }

	    // Private constructor
	    private Const_JA_03(int age) {
	        this.name = "Private";
	        this.age = age;
	        System.out.println("Private constructor called: Name = " + this.name + ", Age = " + this.age);
	    }


	public static void main(String[] args) {
		// Call the public constructor
		Const_JA_03 s1 = new Const_JA_03();

        // Call the protected constructor
		Const_JA_03 s2 = new Const_JA_03("Protected");

        // Call the default (package-private) constructor
		Const_JA_03 example3 = new Const_JA_03("Default", 30);

        // Call the private constructor within the same class
		Const_JA_03 example4 = new Const_JA_03(25);
		

	}

}
