package com.constructors12;
//2. Call the constructors(both default and argument constructors) 
//of super class from a child class

public class Const_JA_02 {
	int eid;
	String ename;
	//Default constructor
	Const_JA_02(){
		System.out.println("hello chaining constr");
	}
	//Parameterized chaining constructor
	Const_JA_02(int eid,String ename){
		System.out.println("hello ppp");
		this.eid=eid;
		this.ename=ename;
		
		
	}

	public static void main(String[] args) {
		Const_JA_02 c1=new Const_JA_02();
		Const_JA_02 c2=new Const_JA_02(27,"hello");
		System.out.println("paramterised constructor: "+c2.eid);
		System.out.println("parameterise constructor: "+c2.ename);

	}

}
