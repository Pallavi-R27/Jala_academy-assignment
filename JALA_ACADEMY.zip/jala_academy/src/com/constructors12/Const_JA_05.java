package com.constructors12;
//5. Try to call the constructor multiple times with the same object.

public class Const_JA_05 {
	 private int number;
	    private String text;

	    // Constructor with both int and String parameters
	    public Const_JA_05(int number, String text) {
	        this.number = number;
	        this.text = text;
	        System.out.println("Constructor called: Number = " + this.number + ", Text = " + this.text);
	    }


	public static void main(String[] args) {
		Const_JA_05 obj1 = new Const_JA_05(10, "First Instance");
		Const_JA_05 obj2 = new Const_JA_05(20, "Second Instance");
		Const_JA_05 obj3 = new Const_JA_05(30, "Third Instance");

      // Output the state of each object
     System.out.println("obj1: Number = " + obj1.number + ", Text = " + obj1.text);
     System.out.println("obj2: Number = " + obj2.number + ", Text = " + obj2.text);
     System.out.println("obj3: Number = " + obj3.number + ", Text = " + obj3.text);
		

	}

}
