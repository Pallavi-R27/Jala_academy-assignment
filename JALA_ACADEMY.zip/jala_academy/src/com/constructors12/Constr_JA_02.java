package com.constructors12;

public class Constr_JA_02 extends Const_JA_02 {

	public static void main(String[] args) {
		//default parameterised constructor.
		

	}

}
