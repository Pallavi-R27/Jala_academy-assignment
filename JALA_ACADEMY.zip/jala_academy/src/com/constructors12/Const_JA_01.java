package com.constructors12;
/*1. Write a class with a default constructor, one argument 
constructor and two argument constructors. Instantiate the class to call 
all the constructors of that class from a main 
class*/

public class Const_JA_01 {
	String name;
	int num;
	//default constructor
	Const_JA_01(){
		this.name="hello";
		this.num=12;
		 System.out.println("Default constructor:" + "name: "+this.name +",num: " + this.num);
	}
	//One-argument constructor
	Const_JA_01(String name){
		this.name=name;
		this.num=num;
		System.out.println("One-argument constructor:"+"name: "+ this.name+" num:"+this.num);
	}
	//two-argument constructor
	Const_JA_01(String name,int num){
		this.name=name;
		this.num=num;
		System.out.println("Two-argument constructor :"+"name: "+this.name+" num: "+this.num);
	}

	public static void main(String[] args) {
		// Call the default constructor
		Const_JA_01 person1 = new Const_JA_01();

        // Call the one-argument constructor
		Const_JA_01 person2 = new Const_JA_01("Alice");

        // Call the two-argument constructor
		Const_JA_01 person3 = new Const_JA_01("Bob", 25);
		
		

	}

}
