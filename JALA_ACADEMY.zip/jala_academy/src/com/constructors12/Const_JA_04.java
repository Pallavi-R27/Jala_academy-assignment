package com.constructors12;
//4. Write constructors with return type int and String.

public class Const_JA_04 {
	private int number;
    private String text;

    // Default constructor
    public Const_JA_04() {
        this.number = 0;
        this.text = "Default";
        System.out.println("Default constructor called: Number = " + this.number + ", Text = " + this.text);
    }

    // Constructor with int parameter
    public Const_JA_04(int number) {
        this.number = number;
        this.text = "Initialized with int";
        System.out.println("Constructor with int called: Number = " + this.number + ", Text = " + this.text);
    }

    // Constructor with String parameter
    public Const_JA_04(String text) {
        this.number = 0;
        this.text = text;
        System.out.println("Constructor with String called: Number = " + this.number + ", Text = " + this.text);
    }

    // Method that returns an int
    public int getNumber() {
        return this.number;
    }

    // Method that returns a String
    public String getText() {
        return this.text;
    }

	public static void main(String[] args) {
		 // Using the default constructor
		Const_JA_04 obj1 = new Const_JA_04();
        System.out.println("obj1 number: " + obj1.getNumber());
        System.out.println("obj1 text: " + obj1.getText());

        // Using the constructor with int parameter
        Const_JA_04 obj2 = new Const_JA_04(42);
        System.out.println("obj2 number: " + obj2.getNumber());
        System.out.println("obj2 text: " + obj2.getText());

        // Using the constructor with String parameter
        Const_JA_04 obj3 = new Const_JA_04("Hello, World!");
        System.out.println("obj3 number: " + obj3.getNumber());
        System.out.println("obj3 text: " + obj3.getText());

	}

}
