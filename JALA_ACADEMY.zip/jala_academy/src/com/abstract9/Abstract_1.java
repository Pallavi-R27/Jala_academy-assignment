package com.abstract9;
//1. Create an abstract class with abstract and non-abstract methods.
public abstract class Abstract_1 {
	// Abstract method (does not have a body)
	abstract void method();
	// Non-abstract method (with a body)
    void sleep() {
        System.out.println("This animal is sleeping.");
    }
    
    // Another non-abstract method
    void eat() {
        System.out.println("This animal is eating.");
    }
	

}
