package com.abstract9;

public class Abstract_001 extends Abstract_1{

	@Override
	void method() {
		System.out.println("the dog barks!");
		
	}
	@Override
	void sleep() {
		System.out.println("the cat drinks milk");
	}
	
	

}
