package com.abstract9;
// Create a sub class for an abstract class. Create an object 
//in the child class for the abstract class and access the non-abstract methods

public abstract class Abstract_2 {
	 // Non-abstract method
    public void eat() {
        System.out.println("This animal eats food.");
    }

    // Abstract method
    public abstract void makeSound();
}


