package com.abstract9;

public class Abstract_04 extends Abstract_4{

	@Override
	public void study() {
		System.out.println("dreams don't unless you do!!");
		
	}

	public void callmethod() {
		Abstract_04 we =new Abstract_04();
		we.job();
	}

}
