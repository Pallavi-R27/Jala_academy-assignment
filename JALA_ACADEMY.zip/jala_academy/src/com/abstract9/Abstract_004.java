package com.abstract9;

public class Abstract_004 {

	public static void main(String[] args) {
		Abstract_04 hey =new Abstract_04();
		//calling the non-abstract method.
		hey.callmethod();
		
		

	}

}