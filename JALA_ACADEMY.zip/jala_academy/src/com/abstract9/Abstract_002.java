package com.abstract9;

public class Abstract_002 {

	public static void main(String[] args) {
		Abstract_02 g1=new Abstract_02();
		g1.eat();
		g1.makeSound();

	}

}
