package com.abstract9;

public class Abstract_01 {

	public static void main(String[] args) {
		Abstract_1 j1=new Abstract_001();
		j1.method();
		j1.sleep();
		

	}

}
