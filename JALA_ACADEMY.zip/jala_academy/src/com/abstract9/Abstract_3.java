package com.abstract9;

public abstract class Abstract_3 {
	// Abstract method
    public abstract void human();

	

}
