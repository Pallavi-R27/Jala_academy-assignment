package com.abstract9;

public class Abstract_02 extends Abstract_2 {

	@Override
	public void makeSound() {
		System.out.println("Animal makes sound!!");
		
	}

}
