package com.abstract9;

public class Abstract_03 extends Abstract_3 {

	@Override
	public void human() {
		System.out.println("human earns money!!");
	}
	// Method to create an instance of itself and call the abstract method
    public void createAndCall() {
        // Create an instance of Dog within Dog class
        Abstract_03 hi = new Abstract_03();
        // Call the abstract method using the instance
        hi.human();
    }

}
