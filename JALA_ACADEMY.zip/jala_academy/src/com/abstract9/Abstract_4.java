package com.abstract9;
//4. Create an instance for the child class in child class 
//and call non-abstract methods.
public abstract class Abstract_4 {
	//create abstract class
	public abstract void study();
	public  void job() {
		System.out.println("when you study you will get a job!!");
		
	}

}
