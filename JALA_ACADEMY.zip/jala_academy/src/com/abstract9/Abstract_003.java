package com.abstract9;

public class Abstract_003 {

	public static void main(String[] args) {
		Abstract_03 abs=new Abstract_03();
		abs.createAndCall();

	}

}
