package com.exceptionhandling14;
//10. Write a program to generate ClassNotFoundException 
public class Exception_10 {

	public static void main(String[] args) throws ClassNotFoundException {
		Class.forName("driver.oracle.OracleDriver");

	}

}
