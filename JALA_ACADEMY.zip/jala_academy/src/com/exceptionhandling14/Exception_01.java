package com.exceptionhandling14;

//1. Write a program to generate Arithmetic Exception without exception handling.

public class Exception_01 {

	public static void main(String[] args) {
		
		System.out.println(10/0);

	}

}
