package com.exceptionhandling14;
//2. Handle the Arithmetic exception using try-catch block 
public class Exception_02 {

	public static void main(String[] args) {
		try {
			System.out.println("in try");
			System.out.println(10/0);
		}catch(ArithmeticException ae) {
			System.out.println("in catch");
			ae.printStackTrace();
		}

	}

}
