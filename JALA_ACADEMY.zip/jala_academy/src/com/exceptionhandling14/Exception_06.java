package com.exceptionhandling14;
//6. Write a program to create your own exception 
public class Exception_06 extends Exception {
	
	     Exception_06(String message) {
	        super(message);
	    }

	public static void main(String[] args) {
		

	}

}
