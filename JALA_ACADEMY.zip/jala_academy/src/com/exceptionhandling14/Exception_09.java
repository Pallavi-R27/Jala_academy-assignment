package com.exceptionhandling14;
//9. Write a program to generate ArrayIndexOutOfBoundException 
public class Exception_09 {

	public static void main(String[] args) {
		int[] num=new int[5];
		num[0]=10;
		num[1]=20;
		num[2]=30;
		num[3]=40;
		num[4]=50;
		num[5]=60;
		try {
			for(int i=0;i<num.length;i++) {
				System.out.println(num[i]);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		

	}

}
