package com.exceptionhandling14;
//8. Write a program to generate Arithmetic Exception
public class Exception_08 {

	public static void main(String[] args) {
		try {
			System.out.println(10/0);
		}catch(ArithmeticException ae) {
			ae.printStackTrace();
		}
		

	}

}
