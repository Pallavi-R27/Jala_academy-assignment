package com.exceptionhandling14;
//16. Write a program to generate NumberFormatException.
public class Exception_16 {

	public static void main(String[] args) {
		try {
		      String str = "xyz";

		      int num = Integer.parseInt(str);

		      System.out.println("Number is: " + num);
		    } catch (NumberFormatException e) {
		    	
		      System.out.println("Exception: " + e);
		    }
		    System.out.println("Program Finished");
		  }
		

	}


