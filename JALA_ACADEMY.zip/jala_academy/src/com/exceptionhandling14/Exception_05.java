package com.exceptionhandling14;
//5. Write a program to throw exception with your own message 
public class Exception_05 extends RuntimeException {
	Exception_05(String s){
		super(s);
		
	}

	public static void main(String[] args) {
		

	}

}
