package com.exceptionhandling14;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.File;
//12. Write a program to generate IOException.
public class Exception_12 {
	public static void main(String args[]) {
	File fr=new File("d:\\java.checkedexps\\dad.txt");
	try {
		fr.createNewFile();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

}

}
