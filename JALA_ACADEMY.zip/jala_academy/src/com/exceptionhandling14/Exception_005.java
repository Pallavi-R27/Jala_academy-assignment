package com.exceptionhandling14;
import java.util.Scanner;
public class Exception_005 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the age: ");
		int num=sc.nextInt();
		if(num>18) {
			System.out.println("eligible to vote!!");
		}else {
			throw new Exception_05("Yes!! kid thow the exception!!");
		}
		

	}

}
