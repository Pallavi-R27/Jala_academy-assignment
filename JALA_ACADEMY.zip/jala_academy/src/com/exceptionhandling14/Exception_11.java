package com.exceptionhandling14;
//11. Write a program to generate FileNotFoundException.
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
public class Exception_11 {

	public static void main(String[] args) {
		try {
			//here i saved in the c drive but i written in d so excepiton gets.
			FileReader fr=new FileReader("d:\\java.checkedexps\\dad.txt");
			try {
				int n=fr.read();
				
				while(n != -1) {
					System.out.print((char)n);
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					n=fr.read();
				}
			}catch(IOException ie) {
				ie.printStackTrace();
			}
			}catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
	}
	  
}
