package com.exceptionhandling14;

import java.sql.DriverManager;
import java.sql.SQLException;

//18. Write a program to generate SQLException 
public class Exception_18 {

	public static void main(String[] args) throws SQLException {
		DriverManager.getConnection("jdbd:oracle:thin:@localhost:1521:XE","System","Admin");
		

	}

}
