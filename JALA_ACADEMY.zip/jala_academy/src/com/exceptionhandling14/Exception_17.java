package com.exceptionhandling14;
//17. Write a program to generate StringIndexOutOfBoundsException 
public class Exception_17 {

	public static void main(String[] args) {
		try {
			String s="hello java";
			 char ch = s.charAt(10);
			System.out.println(ch);
		}catch(RuntimeException re) {
			re.printStackTrace();
		}

	}

}
