package com.exceptionhandling14;
//4. Write a program with multiple catch blocks 
public class Exception_04 {

	public static void main(String[] args) {
		try {
			int[] num= {1,2,3};
			int result=10/0;
			int value=num[5];
			System.out.println(value);
			System.out.println(result);
			
		}catch(ArithmeticException e) {
			System.out.println("arithmeticexception");
			e.printStackTrace();
		}catch(ArrayIndexOutOfBoundsException ae) {
			System.out.println("arrayindexoutofboundsexception");
		}
	}

}
