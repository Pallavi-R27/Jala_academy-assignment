package com.exceptionhandling14;

public class Exception_006 {
	public static void main(String[] args) {
	    try {
            checkNumber(10);
        } catch (Exception_06 e) {
            System.out.println("Caught: " + e.getMessage());
        }
    }

    static void checkNumber(int num) throws Exception_06 {
        if (num < 10) {
            throw new Exception_06("Number is too small!");
        } else {
            System.out.println("Number is acceptable.");
        }
    }
}
		


