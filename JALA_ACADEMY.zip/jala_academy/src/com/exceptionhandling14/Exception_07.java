package com.exceptionhandling14;
//7. Write a program with finally block 
public class Exception_07 {

	public static void main(String[] args) {
		 try {
			 System.out.println(10/0);
		 }catch(ArithmeticException e) {
			 e.printStackTrace();
			 
		 }finally {
			 System.out.println("This is the finally block, executed no matter what.");
		 }

	}

}
