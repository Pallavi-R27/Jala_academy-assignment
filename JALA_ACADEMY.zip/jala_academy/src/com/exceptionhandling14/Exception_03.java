package com.exceptionhandling14;
//3. Write a method which throws exception, Call that method in main class without try block.
public class Exception_03 {
	// Method that throws an ArithmeticException
    public static void generateException() throws ArithmeticException {
    	System.out.println(10/0);
    	
    	
    }
    

	public static void main(String[] args) {
		//Calling the method without a try-catch block
		generateException();
	}

}
