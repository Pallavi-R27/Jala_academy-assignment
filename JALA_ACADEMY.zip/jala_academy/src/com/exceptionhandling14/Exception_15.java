package com.exceptionhandling14;
//15. Write a program to generate NullPointerException 
public class Exception_15 {

	public static void main(String[] args) {
	String s=null;
	try {
		System.out.println(s.length());
	}catch(Exception e) {
		e.printStackTrace();
	}

	}

}
