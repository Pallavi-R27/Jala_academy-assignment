package com.exceptionhandling14;
//14. Write a program to generate NoSuchMethodException 


import java.lang.reflect.Method;
public class Exception_14 {

	public static void main(String[] args) {
			    try {
			      Class c = Class.forName("java.lang.String");

			      Class[] params = new Class[1];
			      Method m = c.getDeclaredMethod("sampleMethod", params);
			    } catch (ClassNotFoundException e) {
			      System.out.println("Exception1: " + e);
			    } catch (NoSuchMethodException e) {
			      System.out.println("Exception2: " + e);
			    }

			    System.out.println("Program finished");
			  }
			
		

	}


