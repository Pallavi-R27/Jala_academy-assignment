package com.file_io_handling_15;

import java.io.FileWriter;
import java.io.IOException;

//6. Write a program to write text to .txt file using FileWriter 
public class File_handling_06 {

	public static void main(String[] args) throws IOException {
		String filePath = "output.txt";  // Specify the path to your .txt file
        String textToWrite = "This is an example of writing text to a file using FileWriter.";

        // Create a FileWriter to write to the specified file
        FileWriter fileWriter = new FileWriter("C:\\java.checkedexps\\text4.txt");

        // Write the text to the file
        fileWriter.write(textToWrite);

        // Close the FileWriter to release resources
        fileWriter.close();
		

	}

}
