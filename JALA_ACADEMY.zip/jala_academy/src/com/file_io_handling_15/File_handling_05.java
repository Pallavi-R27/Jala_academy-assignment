package com.file_io_handling_15;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

//5. Write a program to read text from .txt file using FileReader.
public class File_handling_05 {

	public static void main(String[] args) throws IOException {
		System.out.println("filereader reading the characters!!");
		File f=new File("C:\\java.checkedexps\\dad.txt");
		FileReader fr=new FileReader(f);
		int i=fr.read();
		while(i != -1) {
			System.out.print((char)i);
			i=fr.read();
		}fr.close();
		
		

	}

}
