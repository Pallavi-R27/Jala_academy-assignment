package com.file_io_handling_15;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

//2. Write a program to write text to .txt file using OutputStream.
public class File_handling_02 {

	public static void main(String[] args) throws IOException {
		 String filePath = "C:\\\\java.checkedexps\\\\text2.txt";  // Specify the path to your .txt file
	        String textToWrite = "Hello, this is a sample text written to the file.";

	        OutputStream outputStream = new FileOutputStream(filePath);
	        //FileOutputStream: This is a subclass of OutputStream used to write data to a file.
	      //  textToWrite.getBytes(): Converts the string into a byte array, which can be written to the file.

	        // Convert the string to bytes and write them to the file
	        outputStream.write(textToWrite.getBytes());

	        outputStream.close();
		

	}

}
