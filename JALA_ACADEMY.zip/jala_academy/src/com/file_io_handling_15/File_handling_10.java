package com.file_io_handling_15;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

//10.  Write a program to read data from excel
public class File_handling_10 {

	public static void main(String[] args) throws IOException {
		System.out.println("filereader reading the characters!!");
		File f=new File("C:\\java.checkedexps\\text5.xlsx");
		FileReader fr=new FileReader(f);
		int i=fr.read();
		while(i != -1) {
			System.out.print((char)i);
			i=fr.read();
		}fr.close();

	}

}
