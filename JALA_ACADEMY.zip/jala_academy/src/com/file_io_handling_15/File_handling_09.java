package com.file_io_handling_15;
//9. Write a program to read data from properties file.
public class File_handling_09 {

	public static void main(String[] args) {
		

	}

}
