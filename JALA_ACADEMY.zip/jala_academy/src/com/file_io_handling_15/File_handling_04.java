package com.file_io_handling_15;

import java.io.BufferedOutputStream;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

//4. Write text to a .txt file using BufferedOutputStream.
public class File_handling_04 {

	public static void main(String[] args) throws IOException {
		String filePath = "C:\\java.checkedexps\\text3.txt";  // Specify the path to your .txt file
        String textToWrite = "This is an example of writing text to a file using BufferedOutputStream.";

        // Create a FileOutputStream and wrap it with BufferedOutputStream
        OutputStream outputStream = new BufferedOutputStream(new FileOutputStream(filePath));

        // Convert the string to a byte array
        byte[] textBytes = textToWrite.getBytes();

        // Write the byte array to the file
        outputStream.write(textBytes);

        // Flush and close the OutputStream to ensure all data is written and resources are released
        outputStream.flush();
        outputStream.close();
		
	}

}
