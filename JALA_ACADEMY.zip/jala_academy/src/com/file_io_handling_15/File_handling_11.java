package com.file_io_handling_15;
//11.  Write a program to write data from excel 
public class File_handling_11 {

	public static void main(String[] args) {
		
	}

}
