package com.file_io_handling_15;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

//8. Write text to a .txt file using BufferedWriter 
public class File_handling_08 {

	public static void main(String[] args) throws IOException {
		String filePath = "output.txt";  // Specify the path to your .txt file
        String textToWrite = "This is an example of writing text to a file using BufferedWriter.";

        // Create a BufferedWriter to write to the specified file
        try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter("C:\\java.checkedexps\\text4.txt"))) {
            // Write the text to the file
            bufferedWriter.write(textToWrite);
        }

	}

}
