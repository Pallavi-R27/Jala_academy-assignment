package com.file_io_handling_15;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

//7. Read text from a .txt file using BufferedReader.
public class File_handling_07 {

	public static void main(String[] args) throws IOException {
		BufferedReader reader = new BufferedReader(new FileReader("C:\\java.checkedexps\\text2.txt"));

        String line;
        while ((line = reader.readLine()) != null) {
            System.out.println(line);
        }

        // Close the BufferedReader to release resources
        reader.close();
		

	}

}
