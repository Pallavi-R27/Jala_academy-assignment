package com.file_io_handling_15;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

//3. Read text from a .txt file using BufferedInputStream
public class File_handling_03 {

	public static void main(String[] args) throws IOException {
		InputStream input=new BufferedInputStream(new FileInputStream("C:\\java.checkedexps\\text2.txt"));
		int i=input.read();
		while( i != -1) {
			char ch= (char)i;
			i=input.read();
			System.out.print(ch);
			
		}input.close();

	}

}
