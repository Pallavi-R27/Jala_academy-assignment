package com.Operators;
//3.Program to equal operator and not equal operators 

public class Oper_JA_03 {

	public static void main(String[] args) {
		int a=10;
		int b=10;
		
		System.out.println("using equal operator: "+isequal(a,b));
		System.out.println("using notequal operator: "+notequal(a,b));
		
	}
	 // Method to check if two numbers are equal.
	public static boolean isequal(int a,int b) {
		return a==b;
	}
	 // Method to check if two numbers not equal.
	public static boolean notequal(int a,int b) {
		return a != b;
	}

}
