package com.Operators;
//6. Program for relational operators (<,<==, >, >==) 

public class Oper_JA_06 {

	public static void main(String[] args) {
		int a=12;
		int b=14;
		
		System.out.println(a<b);
		System.out.println(a<=b);
		System.out.println(a>b);
		System.out.println(a>=b);
		

	}

}
