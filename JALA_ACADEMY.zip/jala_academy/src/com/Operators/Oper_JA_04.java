package com.Operators;
import java.util.Scanner;
//4. Write a program to find the two numbers equal or not. 

public class Oper_JA_04 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the first number: ");
		int a=sc.nextInt();
		System.out.println("enter the second number: ");
		int b=sc.nextInt();
		if(a==b) {
			System.out.println("two numbers are equal");
		}
		else {
			System.out.println("two numbers are not equal");
		}
	sc.close();
		

	}

}
