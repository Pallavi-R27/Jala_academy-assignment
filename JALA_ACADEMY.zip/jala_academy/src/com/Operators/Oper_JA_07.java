package com.Operators;
//7.Print the smaller and larger number.
import java.util.Scanner;

public class Oper_JA_07 {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		System.out.println("enter the first number:");
		int a=sc.nextInt();
		System.out.println("enter the second number: ");
		int b=sc.nextInt();
		
		int small_num= (a<b) ? a :b;
		System.out.println("smallest number:"+small_num);
		
		int large_num= (a>b) ? a: b;
		System.out.println("largest number:"+large_num);
		

	}

}
