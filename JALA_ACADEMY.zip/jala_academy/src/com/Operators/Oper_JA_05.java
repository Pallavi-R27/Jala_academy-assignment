package com.Operators;
import java.util.Scanner;
//5. Programs on Logical AND,OR operator and Logical NOT.

public class Oper_JA_05 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter first number: ");
		int a=sc.nextInt();
		System.out.println("enter second number: ");
		int b=sc.nextInt();
		
		boolean cond1 =a>0;
		boolean cond2=b>0;
		
		boolean andresult=cond1 && cond2;
		System.out.println("both are positive: "+andresult);
		
		boolean orresult=cond1 || cond2;
		System.out.println("atleast one should be postivie: "+orresult);
		
		boolean notresult= !cond1;
		System.out.println("The first number is not positive: "+notresult);
		
		boolean notresult2= !cond2;
		System.out.println("The second number is not positive: "+ notresult2);
		
		sc.close();	
		

	}
	

}
