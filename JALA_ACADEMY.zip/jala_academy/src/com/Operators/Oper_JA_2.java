package com.Operators;
//1. Write a function for arithmetic operators(+,-,*,/).

public class Oper_JA_2 {

	public static void main(String[] args) {
		int a=40;
		int b=30;
		
		System.out.println("Addition"+add(a,b));
		System.out.println("Subtraction:" +sub(a,b));
		System.out.println("Multiplication:"+multi(a,b));
		System.out.println("Division:"+divi(a,b));
		
		
		

	}
	   // Function for addition
	 public static int add(int a, int b) {
	        return a + b;
	 }
	// Function for subtraction
	 public static int sub(int a,int b) {
		 return a-b;
	 }
	    // Function for multiplication
	 public static int multi(int a,int b) {
		 return a*b;
	 }
	    // Function for division
	 public static int divi(int a, int b) {
		 return a/b;
	 }

}
