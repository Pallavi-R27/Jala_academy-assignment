package com.Operators;
//2. Write a method for increment and decrement operators(++, --).

public class Oper_JA_02 {

	public static void main(String[] args) {
		int a=10;
		System.out.println("After increment"+increment(a));
		System.out.println("After Decrement:"+decrement(a));
		
		
		
		

	}
	 // Method to increment the value by 1
	public static int increment(int a) {
		return ++a;
	}
	 // Method to decrement the value by 1
	public static int decrement(int a) {
		return --a;
	}

}
