package com.this_super_11;

public class This_super_005 extends This_super_05 {
	int y1;
	
	This_super_005(int x,int y1) {
		super(x);
		this.y1=y1;
		System.out.println("child constructor called y1= "+y1);
		
	}


	int y;
	

	public static void main(String[] args) {
		This_super_005 c2=new This_super_005(10,20);
		

	}

}
