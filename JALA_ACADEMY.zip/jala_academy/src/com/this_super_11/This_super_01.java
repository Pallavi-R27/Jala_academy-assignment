package com.this_super_11;
//1. Print the fields/instance members of the current class using this and 
//without using object

public class This_super_01 {
	private int field1 = 10;
    private String field2 = "Hello";
    private double field3 = 20.5;

    public void printFields() {
        System.out.println("field1 = " + this.field1);
        System.out.println("field2 = " + this.field2);
        System.out.println("field3 = " + this.field3);
    }

    
       

	public static void main(String[] args) {
		This_super_01 myObject = new This_super_01();
	        myObject.printFields();
		

	}

}
