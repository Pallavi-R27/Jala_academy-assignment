package com.this_super_11;
//6.Use this() and super() in methods not in constructors

public class This_super_06 {
	String name;
	This_super_06(String name){
		this.name=name;
		
	}
	void display() {
		System.out.println("parent name "+name);
	}
	

	public static void main(String[] args) {
		
		

	}

}
