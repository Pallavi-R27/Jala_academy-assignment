package com.this_super_11;
//4.Call argument constructor of current class using this().


public class This_super_04 {
	private int x;
    private int y;

    // Default constructor
    public This_super_04() {
        this(0, 0); 
        // Calls the constructor with two arguments
    }

    // Constructor with one argument
    public This_super_04(int x) {
        this(x, 0); 
        // Calls the constructor with two arguments
    }

    // Constructor with two arguments
    public This_super_04(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // Display method to show values
    public void display() {
        System.out.println("x: " + x + ", y: " + y);
    }

    public static void main(String[] args) {
    	This_super_04 obj1 = new This_super_04();
        obj1.display();

        This_super_04 obj2 = new This_super_04(10);
        obj2.display();

        This_super_04 obj3 = new This_super_04(20, 30);
        obj3.display();
    }
	 
	

}
