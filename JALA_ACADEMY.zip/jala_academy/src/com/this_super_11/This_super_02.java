package com.this_super_11;
//2. Print the fields/instance members of the parent class using super

public class This_super_02 {
	protected int parentField1 = 100;
    protected String parentField2 = "Parent Field";
    protected double parentField3 = 50.5;

    public void printParentFields() {
        System.out.println("parentField1 = " + parentField1);
        System.out.println("parentField2 = " + parentField2);
        System.out.println("parentField3 = " + parentField3);
    }

	public static void main(String[] args) {
		

	}

}
