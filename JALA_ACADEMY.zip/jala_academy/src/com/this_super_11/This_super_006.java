package com.this_super_11;

public class This_super_006 extends This_super_06 {
	String name1;
	This_super_006(String name,String name1){
		super(name);
		this.name1=name1;
		
	}
	void display() {
        // Call the parent class display() method
        super.display();
        System.out.println("child method: " + name1);
    }

    void showDetails() {
        // Call the current class display() method
        this.display();
    }
	
	

	public static void main(String[] args) {
		This_super_006 c5=new This_super_006("hello","java");
		c5.showDetails();
		

	}

}
