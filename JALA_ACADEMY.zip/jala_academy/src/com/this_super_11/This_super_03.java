package com.this_super_11;
//3. Call constructor of the current class using this()

public class This_super_03 {
	private int field1;
	private String field2;
	private double field3;
	//default parameterised constructor.
	public This_super_03(){
		this(12,"java",20.3);
		System.out.println("default constructor called!!");
		}
	//parameterised constructor
	public This_super_03(int field1,String field2,double field3) {
		this.field1=field1;
		this.field2=field2;
		this.field3=field3;
		System.out.println("paramterised constructor called!!");
	}
	 public void printfields() {
	        System.out.println("field1 = " + this.field1);
	        System.out.println("field2 = " + this.field2);
	        System.out.println("field3 = " + this.field3);
	    }

	public static void main(String[] args) {
		This_super_03 s1=new This_super_03();
		s1.printfields();
		System.out.println();
		This_super_03 s2=new This_super_03(14,"python",37.4);
		s2.printfields();
		

	}

}
