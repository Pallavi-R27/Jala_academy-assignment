package com.this_super_11;
//5. Call constructor of the parent class using super() 
public class This_super_05 {
	int x;
	//paramterised constructor
	This_super_05(int x){
		this.x=x;
		System.out.println("parent constructor called with x= "+x);
	}
	

	public static void main(String[] args) {
		This_super_05 c1=new This_super_05(10);
		

	}

}
