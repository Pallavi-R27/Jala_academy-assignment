package com.javabasics;
//2. Write a program to print your name.

public class Javabasics_JA_02 {

	public static void main(String[] args) {
		String name="Pallavi";
		System.out.println(name);

	}

}
