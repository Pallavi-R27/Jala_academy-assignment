package com.javabasics;
//4.  Define variables for different Data Types int, Boolean, char, 
//float, double and print on the Console.

public class Javabasics_JA_04 {

	public static void main(String[] args) {
		int num=27;
		boolean valid=true;
		String name="tommy";
		char a='P';
		float num1=4.6f;
		double num2=4.555;
		System.out.println(num);
		System.out.println(name);
		System.out.println(a);
		System.out.println(num1);
		System.out.println(num2);
		System.out.println(valid);
		
	}

}
