package com.javabasics;
//5. Define the local and Global variables with the same name and 
//print both variables and understand the scope of the variables.

/*Global Variables: Variables that are declared inside a class but outside 
any method. They can be accessed by all methods in the class.
Local Variables: Variables that are declared inside a method. They can only be 
accessed within that method.*/



public class Javabasics_JA_05 {
	String name="tommy";
	
	public void displayName() {
        // Local variable with the same name as the global variable
        String name = "Tom";

        // Print the local variable
        System.out.println("Local variable name: " + name);

        // Print the global variable using 'this' keyword
        System.out.println("Global variable name: " + this.name);
    }


	public static void main(String[] args) {
		Javabasics_JA_05 demo=new Javabasics_JA_05();
		demo.displayName();

	}

}
