package com.javabasics;
//6. Write a function to print your name and call the function from main method.

public class Javabasics_JA_06 {
	//function to print name
		public void Printmyname() {
			System.out.println("Pallavi");
		}

	public static void main(String[] args) {
		Javabasics_JA_06 name=new Javabasics_JA_06();
		name.Printmyname();
		
		

	}

}
