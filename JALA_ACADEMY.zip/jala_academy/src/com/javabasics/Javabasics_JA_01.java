package com.javabasics;
//1. How to create a class, object, method and its signature.
//A method is a block of code which only runs when it is called.
//You can pass data, known as parameters, into a method.
//Methods are used to perform certain actions, and 
//they are also known as functions.



public class Javabasics_JA_01 {
	static void myMethod() {
	    System.out.println("hello method!");
	  }
	//creating an object
	 int x = 5;
	 // To create an object of Java_basics_2 , specify the class 
	 // name, followed by the object name, and use the keyword new:

	
		
	public static void main(String[] args) {
		myMethod();
		Javabasics_JA_01 num = new Javabasics_JA_01();
	    System.out.println(num.x);
		

	}

}
