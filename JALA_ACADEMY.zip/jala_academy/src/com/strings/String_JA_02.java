package com.strings;
//2. Concatenating two strings using + operator 

public class String_JA_02 {

	public static void main(String[] args) {
		String str1="hello";
		String str2="string";
		System.out.println(str1+" "+str2);
		

	}

}
