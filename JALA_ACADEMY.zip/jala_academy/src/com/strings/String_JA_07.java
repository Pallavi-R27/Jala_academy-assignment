package com.strings;
//7. Comparing strings using the methods equals(),

public class String_JA_07 {

	public static void main(String[] args) {
		String word="jala academy";
		String word1="jala academy";
		boolean word2=word.equals(word1);
		System.out.println(word2);
		
	}

}
