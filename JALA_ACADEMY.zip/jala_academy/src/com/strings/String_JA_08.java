package com.strings;
//8. equalsIgnoreCase(), startsWith(), endsWith() and compareTo().

public class String_JA_08 {

	public static void main(String[] args) {
		String word="Hello";
		String name="hello";
		//equalsIgnorecase compare two strings ignore the case considerations
		boolean word2=word.equalsIgnoreCase(name);
		System.out.println(word2);
		boolean result=word.startsWith("Hello");
		System.out.println(result);
		int value=word.compareTo(name);
		if(value<0) {
			System.out.println("word less than name");
		}else if(value==0){
			System.out.println("word equlas to name");
			
		}else {
			System.out.println("word equals to the name");
		}
		

	}

}
