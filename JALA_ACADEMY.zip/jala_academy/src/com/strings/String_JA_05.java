package com.strings;
//5. Searching in strings using indexOf() 

public class String_JA_05 {

	public static void main(String[] args) {
		String str="java";
		int index=str.indexOf('j');
		System.out.println(index);

	}

}
