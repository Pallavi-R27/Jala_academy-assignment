package com.strings;
//12. Converting Numbers to Strings with valueOf().

public class String_JA_12 {

	public static void main(String[] args) {
		int number = 123;
        String str = String.valueOf(number);
        System.out.println("String representation of int: " + str);
		

	}

}
