package com.strings;
//4. Extract a string using Substring 

public class String_JA_04 {

	public static void main(String[] args) {
		String str = "Hello, World!";
        String substr = str.substring(7);
        System.out.println("Substring: " + substr);
		

	}

}
