package com.strings;
//1. Different ways creating a string 

public class String_JA_01 {
	public static void main(String[] args) {
		//type 1
		String name="Pallavi";
		System.out.println(name);
		//2.using new keyword
		String str2 = new String("Hello, World!");
		System.out.println(str2);
		//3.using array
		char[] charArray = {'H', 'e', 'l', 'l', 'o'};
		String str3 = new String(charArray);
		System.out.println(str3);
		//4.Using String.valueOf Method
      /*The String.valueOf method can be used to convert different data
		types to a string.*/
		int number = 123;
		String str4 = String.valueOf(number);
		System.out.println(str4);
		//5.Using String.concat Method
		String str9 = "Hello".concat(", World!");
		System.out.println(str9);


     }

}
