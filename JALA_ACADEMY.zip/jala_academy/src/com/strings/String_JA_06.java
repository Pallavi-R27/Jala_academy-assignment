package com.strings;
//6. Matching a String Against a Regular Expression With matches().

public class String_JA_06 {

	public static void main(String[] args) {
		String word="python";
		boolean word1=word.matches("python");
		System.out.println(word1);
		

	}

}
