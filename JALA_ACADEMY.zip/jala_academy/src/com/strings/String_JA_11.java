package com.strings;
//11. Splitting strings with split() 

public class String_JA_11 {

	public static void main(String[] args) {
		String value="apple,banana,cherry";
		String[] word=value.split(",");
		for(String friut:word) {
			System.out.println(friut);
		}

	}

}
