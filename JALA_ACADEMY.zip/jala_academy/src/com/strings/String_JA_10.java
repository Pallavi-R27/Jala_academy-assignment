package com.strings;
//10. Replacing characters in strings with replace().

public class String_JA_10 {

	public static void main(String[] args) {
		 String str = "the quick brown fox jumps over the lazy dog";
	     String replacedStr = str.replace("fox", "cat");
	     System.out.println("Original: " + str); // Output: Original: the quick brown fox jumps over the lazy dog
	     System.out.println("Replaced: " + replacedStr);
	     String word="hello world";
	     String replace1=word.replace('l','x');
	     System.out.println(replace1);
		

	}

}
