package com.strings;
//9. Trimming strings with trim() 
//trim() removes the space between the white spaces.

public class String_JA_09 {

	public static void main(String[] args) {
		String var=" hello world ";
		String value="    ";
		System.out.println(var.trim());
		System.out.println(value.trim());
		

	}

}
