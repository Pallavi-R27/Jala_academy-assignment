package com.strings;
//13. Converting integer objects to Strings.

public class String_JA_13 {

	public static void main(String[] args) {
		int number = 123;
		String str = String.valueOf(number);
		System.out.println(str);
		

	}

}
