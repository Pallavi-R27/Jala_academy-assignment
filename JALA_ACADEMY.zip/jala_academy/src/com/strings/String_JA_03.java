package com.strings;
//3. Finding the length of the string 

public class String_JA_03 {

	public static void main(String[] args) {
		String word="jala academy";
		System.out.println("length of the string: "+word.length());
		

	}

}
