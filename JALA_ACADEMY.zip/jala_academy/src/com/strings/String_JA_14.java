package com.strings;
//14. Converting to uppercase and lowercase

public class String_JA_14 {

	public static void main(String[] args) {
		String original="full stack java";
		String org="FULL STACK JAVA";
		String upperstring=original.toUpperCase();
		System.out.println("coverting to upper case string:"+upperstring);
		String lowerstring=org.toLowerCase();
		System.out.println("converting to lower case string:"+lowerstring);
		
		

	}

}
