package com.inheritance7;

public class Mainclass {

	public static void main(String[] args) {
		A a=new A();
		B b =new B();
		C c=new C();
		//calling methods of class A
		a.method1();
		a.method2();
		a.commonmethod();
		//calling methods of class B
		b.methodb();
		b.methodb2();
		b.method1();      //inherited from class A
		b.method2();     //inherited from class A
		b.commonmethod();
		//calling methods of class C
		c.methodc();
		c.methodc2();
		c.methodb();  //inherited from class B
		c.method2();  // inherited from class B
		c.method1();   //inherited from class A
		c.method2();   //inherited from class A
		c.commonmethod();
		
		// Calling overridden method with superclass reference
        A refB = new B();
        A refC = new C();
        refB.commonmethod();
        refC.commonmethod();
        // Runtime Polymorphism with Data Members
        System.out.println("Data member in A: " + a.data);
        System.out.println("Data member in B: " + b.datab + ", " + b.datab);
        System.out.println("Data member in C: "+c.data+", "+c.datab+", "+c.datac);
   
		

	}

}
