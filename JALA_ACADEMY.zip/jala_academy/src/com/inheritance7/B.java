package com.inheritance7;

public class B extends A{
	int datab=20;
	public void methodb() {
		System.out.println("methodb from class B");
	}
	public void methodb2() {
		System.out.println("methodb2 from class B");
	}
	@Override
	public void commonmethod() {
		System.out.println("common method from class B");
	}
	
	

}
