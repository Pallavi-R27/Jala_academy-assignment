package com.inheritance7;

public class C extends B{
	int datac=30;
	public void methodc() {
		System.out.println("method1 from class C");
	}
	public void methodc2() {
		System.out.println("method2 from class C");
	}
	@Override
	public void commonmethod() {
		System.out.println("common method from class C");
	}
	

}
