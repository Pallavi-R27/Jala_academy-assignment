package com.inheritance7;

public class A {
	int data=10;
	public void method1() {
		System.out.println("method1 from class A");
	}
	public void method2() {
		System.out.println("method2 from class A");
	}
	public void commonmethod() {
		System.out.println("common method from class A");
	}

}
