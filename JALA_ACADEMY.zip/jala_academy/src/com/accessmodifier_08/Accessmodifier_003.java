package com.accessmodifier_08;
import com.accessmodifiers8.Accessmodifiers_03;
import com.accessmodifiers8.Accessmodifiers_04;
public class Accessmodifier_003 extends Accessmodifiers_03 {

	public static void main(String[] args) {
		//accessing protected 
		Accessmodifiers_03 b1=new Accessmodifiers_03();
		Accessmodifier_003 b2=new Accessmodifier_003();
		System.out.println("protected filed:"+b2.num);
		System.out.println("protected filed:"+b2.name);
		b2.method2();
		
		//accessing public modifier.
		Accessmodifiers_04 d1=new Accessmodifiers_04();
		System.out.println("printing fields:"+d1.id);
		System.out.println("printing fields:"+d1.id_name);
		d1.method3();
		

	}

}
