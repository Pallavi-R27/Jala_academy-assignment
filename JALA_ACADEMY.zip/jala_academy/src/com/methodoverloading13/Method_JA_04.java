package com.methodoverloading13;
/*4. Write two methods with the same name and same number of parameters of different 
type and call from main method*/
public class Method_JA_04 {
	static void method(int a,float b) {
		System.out.println("passing integer and float: "+a +","+b);
	}
	static void method(long c, Double d) {
		System.out.println("passing long and double: "+c+", "+d);
	}

	public static void main(String[] args) {
		method(23, 345.0f);
		method(56L,8765.9);
		
	}

}
