package com.methodoverloading13;
//1. Write two methods with the same name but different number of parameters of same type 
//and call the methods from main method.
public class Method_JA_01 {
	static void method(int a) {
		System.out.println("method with one parameter: "+a);
	}
	static void method(int a,int b) {
		System.out.println("method with two parameters: "+a+", "+b);
	}

	public static void main(String[] args) {
		method(10);
		method(20,30);
		
		

	}

}
