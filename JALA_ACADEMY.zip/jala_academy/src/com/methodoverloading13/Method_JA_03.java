package com.methodoverloading13;
//3. Write two methods with the same name and same number of parameters of same type 
//and call from main method
public class Method_JA_03 {
//	static void addition(int a,int b) {
//		System.out.println("passing same of data arguments!!"+a+","+b);
//		}
//	static void addition(int c,int d) {
//		System.out.println("passing same type data members!!);
//	}
/*you cannot have two methods with the same name and the same number of 
 * parameters of the same type in the same class. This would cause a compilation 
 * error due to method signature conflict.
 */

	public static void main(String[] args) {
		

	}

}
