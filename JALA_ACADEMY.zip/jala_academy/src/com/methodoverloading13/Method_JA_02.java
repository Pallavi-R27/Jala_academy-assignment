package com.methodoverloading13;
//2. Write two methods with the same name but different number of parameters of different
//data type and call the methods from main method
public class Method_JA_02 {
	static void method1(int a,float b) {
		System.out.println("hello integers: "+a+", "+b);
	}
	
	static void method1(String m,char j) {
		System.out.println("hello string && character: "+m+", "+j);
	}

	public static void main(String[] args) {
		method1(3,98.0f);
		method1("lion",'u');
		

	}

}
