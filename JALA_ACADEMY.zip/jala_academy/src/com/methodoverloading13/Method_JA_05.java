package com.methodoverloading13;
//5. Write two methods with the same name, number of parameters and data type but 
//different return Type.
/*you cannot overload methods based solely on different return types, even 
 * if the methods are static. The compiler will not differentiate between methods 
 * based on the return type alone; it requires a different method signature, which 
 * includes the method name and parameter list. Attempting to do so will result in a
 *  compilation error.
 */
public class Method_JA_05 {
//	// Method with int return type
//    public int display(int a) {
//        return a;
//    }
//
//    // Method with double return type
//    // This will cause a compilation error
//    public double display(int a) {
//        return (double) a;
//    }
//
//	public static void main(String[] args) {
//		  // This code will not compile due to the method signature conflict
//        int result1 = display(5);
//        double result2 = display(5);
//
//        System.out.println("Result 1: " + result1);
//        System.out.println("Result 2: " + result2);
		

	}


