package com.interface10;

public class Interface_00007 {

	public static void main(String[] args) {
		Interface_0007 h1=new Interface_0007();
		h1.parent();
		h1.child();

	}

}
