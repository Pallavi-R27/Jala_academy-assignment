package com.interface10;

public class Interface2_11 {

	public static void main(String[] args) {
		Interface1_11 hello=new Interface1_11();
		hello.printMessage();

	}

}
