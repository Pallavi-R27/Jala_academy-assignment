package com.interface10;

public class Interface_00005 {

	public static void main(String[] args) {
		Interface_005 friut=new Interface_0005(); 
		friut.apple();
		friut.grape();

	}

}
