package com.interface10;
//4. Create two interfaces with one method each. Implement
//these two interfaces in one class. 

public interface Interface_04 {
	public abstract void animal();

}
