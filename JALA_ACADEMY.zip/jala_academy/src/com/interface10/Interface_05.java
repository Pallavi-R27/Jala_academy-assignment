package com.interface10;
/*5. Create two interfaces with the same method
(same signature) in both the interfaces. Implement these two 
interfaces in one class. Call the method.*/ 

public interface Interface_05 {
	public abstract void apple();
	public abstract void grape();
}
