package com.interface10;
//10.10. Create an interface with private, public and protected fields.

public interface Interface_10 {

    // Public interface with public fields
    public interface MyPublicInterface {
       // Fields with assigned values
        String greet = "Hello from public interface";
        int num = 42;

        // Method declarations
        void displayPublicGreeting();
        void displayPublicNumber();
    }

    

   


}
