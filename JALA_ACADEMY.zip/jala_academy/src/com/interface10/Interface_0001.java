package com.interface10;

public class Interface_0001 {

	public static void main(String[] args) {
		Interface_01 c1=new Interface_001();
		c1.human();
		c1.dance();
		
		}

	
		
	}


