package com.interface10;

public class Interface_001 implements Interface_01 {

	@Override
	public void human() {
		System.out.println("hello interface!!");
		
	}

	@Override
	public void dance() {
		System.out.println("hello  humans love dance!!");
		
	}

}
