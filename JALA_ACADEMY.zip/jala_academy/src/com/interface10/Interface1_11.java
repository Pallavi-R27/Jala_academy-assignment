package com.interface10;

public class Interface1_11 implements Interface_11{

	@Override
	public void printMessage() {
		System.out.println("count:"+count);
		System.out.println("given word:"+word);
		
	}
	

}
