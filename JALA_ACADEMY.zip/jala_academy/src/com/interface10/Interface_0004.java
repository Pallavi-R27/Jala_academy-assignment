package com.interface10;

public class Interface_0004 implements Interface_04 ,Interface_004 {

	

	@Override
	public void dog() {
		System.out.println("it's a dog");
		
	}

	@Override
	public void animal() {
		System.out.println("zebra is a animal");
	}

}
