package com.interface10;

public class Interface_008 implements Interface_08  {

	@Override
	public void displayGreeting() {
		System.out.println("hello! nice to meet you!! "+greet);
		
	}

	@Override
	public void displayNumber() {
		System.out.println("pin-code of hi-tech "+num);
		
	}

}
