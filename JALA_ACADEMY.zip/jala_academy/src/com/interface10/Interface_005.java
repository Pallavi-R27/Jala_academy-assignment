package com.interface10;

public interface Interface_005 {
	public abstract void apple();
	public abstract void grape();
}
