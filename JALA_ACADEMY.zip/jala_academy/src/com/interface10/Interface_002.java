package com.interface10;

public class Interface_002 implements Interface_02{

	@Override
	public void walk() {
		System.out.println("post dinner walk good for health");
		
	}

	@Override
	public void talk() {
		System.out.println("it's just a talk");
		
	}

	

}
