package com.interface10;

public class Interface_006 implements Interface_06 {

	@Override
	public void method1() {
		System.out.println("hello interface method!!");
		
	}

}
