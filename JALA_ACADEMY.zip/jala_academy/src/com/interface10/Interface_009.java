package com.interface10;

public class Interface_009 implements Interface_09{
	

	@Override
	public void greet() {
		System.out.println("Well come to java programming!!"+greet);
		
	}

	@Override
	public void num() {
		System.out.println("the number is: "+num);
		
	}

}
