package com.interface10;
//3. Use Interface instances to call the implemented method in the implemented class 

public interface Interface_03 {
	//in interface public abstract  is default
	public abstract void method1();
	public abstract void method2();

}
