package com.interface10;

public class Interface_00004 {

	public static void main(String[] args) {
		Interface_0004 d1=new Interface_0004();
		d1.dog();
		d1.animal();
		}

}
