package com.interface10;
//1. Create an interface with only one method and implement it in 
//a class. Call the method implemented.

public interface Interface_01 {
	 public abstract void human();
	 public abstract void dance();

	
	

}
