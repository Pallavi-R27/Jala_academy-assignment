package com.interface10;

public class Interface_003 implements Interface_03 {

	@Override
	public void method1() {
		System.out.println("method1 is implemented");
		
	}

	@Override
	public void method2() {
		System.out.println("nethod2 is implemented");
		
	}

}
