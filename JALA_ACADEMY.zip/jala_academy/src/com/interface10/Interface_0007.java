package com.interface10;

public class Interface_0007 implements  Interface_007 {

	@Override
	public void parent() {
		System.out.println("Hello parent method!!");
		
	}

	@Override
	public void child() {
		System.out.println("Hello children method!!");
		
		
	}

}
