package com.interface10;

public interface Interface_007 extends  Interface_07{
	public abstract void child();

}
