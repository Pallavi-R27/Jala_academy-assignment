package com.interface10;

public class Interface_0003 {

	public static void main(String[] args) {
		Interface_03 c3=new Interface_003();
		c3.method1();
		c3.method2();

	}

}
