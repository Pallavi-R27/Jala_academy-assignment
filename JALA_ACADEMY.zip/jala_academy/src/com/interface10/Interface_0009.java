package com.interface10;

public class Interface_0009 {

	public static void main(String[] args) {
		Interface_009 j1=new Interface_009();
		j1.greet();
		j1.num();
		// Directly access and print the interface fields
        System.out.println("Directly accessing interface fields:");
        System.out.println("Greeting: " +Interface_09.greet);
        System.out.println("Number: " +  Interface_09.num);
    }
		

}


