package com.interface10;
//9.Create a PRIVATE or PROTECTED interface and print the values as above scenario

public interface Interface_09 {
	String greet="Jala Academy";
	int num =7;
	// Method declarations
	void greet();
	void num();
	

}
