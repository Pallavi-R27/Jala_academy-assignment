package com.interface10;

public class Interface_0006 {

	public static void main(String[] args) {
		Interface_06 g1=new Interface_006();
		g1.method();
		g1.method1();
		
		

	}

}
