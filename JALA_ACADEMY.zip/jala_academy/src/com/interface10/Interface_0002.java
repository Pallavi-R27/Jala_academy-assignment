package com.interface10;

public class Interface_0002 extends Interface_002 {

	public static void main(String[] args) {
		Interface_0002 s1=new Interface_0002();
		s1.walk();
		

	}

}
