package com.interface10;
/*8. Create a PUBLIC interface with fields and methods, fields should 
 have values assigned.Implement this interface to some class and print 
 the values of the interface fields and call the interface methods*/

public interface Interface_08 {
	String greet="good mnrg hyd";
	int num=50081;
	
	// Method declarations
    void displayGreeting();
    void displayNumber();

}
