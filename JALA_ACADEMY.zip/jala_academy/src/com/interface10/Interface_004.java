package com.interface10;

public interface Interface_004 {
	public abstract void dog();

}
