package com.interface10;
/*6. Create an interface with a default method and implement it in a class. Do not provide 
 implementation to the default method and call the method.*/

public interface Interface_06 {
	public abstract void method1();
	default void method() {
		System.out.println("hello default method!!");
	}

}
