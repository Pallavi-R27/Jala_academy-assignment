package com.interface10;
//2. Create an interface with two methods, but implement only one in a 
//class. Call the method implemented.

public interface Interface_02 {
	public abstract void walk();
	public abstract void talk();

}
