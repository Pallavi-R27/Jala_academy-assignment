package com.interface10;

public class Interface_0005 implements Interface_05,Interface_005 {

	@Override
	public void apple() {
		System.out.println("apple is a fruit!!");
		
	}

	@Override
	public void grape() {
		System.out.println("grape is good to health");
		
	}

}
