package com.interface10;
//11. Create an interface with static final variable.
public interface Interface_11 {
	 // Static final variables (constants)
    int count = 100;
    String word = "Hello, World!";
    
    // Abstract method
    void printMessage();
}


