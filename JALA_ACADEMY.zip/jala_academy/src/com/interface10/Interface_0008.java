package com.interface10;

public class Interface_0008 {

	public static void main(String[] args) {
		Interface_008 o1=new Interface_008 ();
		o1.displayGreeting();
		o1.displayNumber();
		// Directly access and print the interface fields
        System.out.println("Directly accessing interface fields:");
        System.out.println("Greeting: " +Interface_08.greet);
        System.out.println("Number: " + Interface_08.num);

	}

}
