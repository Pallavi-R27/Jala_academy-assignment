package com.interface10;
//7. Create an interface and inherit it from the other interface. 

public interface Interface_07 {
	public abstract void parent();

}
