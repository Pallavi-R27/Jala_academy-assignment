package com.arrays;
//8. Write a function to find the minimum and maximum value of an array .

public class Array_JA_08 {
	
	 public static int[] findMinMax(int[] array) {
	        if (array == null || array.length == 0) {
	            throw new IllegalArgumentException("Array must not be null or empty");
	        }

	        int min = array[0];
	        int max = array[0];

	        for (int i = 1; i < array.length; i++) {
	            if (array[i] < min) {
	                min = array[i];
	            }
	            if (array[i] > max) {
	                max = array[i];
	            }
	        }

	        return new int[]{min, max};
	    }

	    public static void main(String[] args) {
	        int[] array = {3, 5, 7, 2, 8, -1, 4, 10, 12};

	        int[] minMax = findMinMax(array);

	        System.out.println("Minimum value: " + minMax[0]);
	        System.out.println("Maximum value: " + minMax[1]);
	    }
	}


	