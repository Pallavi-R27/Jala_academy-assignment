package com.arrays;
//1. Write a function to add integer values of an array.

public class Array_JA_01 {
	// Function to add integer values of an array
	public static int SumOfArray(int[] array) {
		int sum=0;
		for(int i=0;i<array.length;i++) {
			sum=sum+array[i];
			
		}
		return sum;
		
	}

	public static void main(String[] args) {
		int[] numbers= {10,20,30,40};
		int result=SumOfArray(numbers);
		System.out.println("The sum of array elements:"+result);
		

	}

}
