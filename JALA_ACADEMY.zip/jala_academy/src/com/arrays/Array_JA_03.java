package com.arrays;
//3. Write a program to find the index of an array element.

public class Array_JA_03 {

	public static void main(String[] args) {
		int [] elements= {10,20,30,40};
		    int ele_find=30;
			int index=find_index(elements,ele_find);
			if (index != -1) {
	            System.out.println("Element " + ele_find + " is at index " + index);
	        } else {
	            System.out.println("Element " + ele_find  + " is not in the array"+index);
	        }
	}
		private static int find_index(int[] array,int elem) {
		for(int i=0;i<array.length;i++) {
			if(array[i]==elem) {
				return i;
				
			}
		}
		return -1;
	}

}
