package com.arrays;
import java.util.Arrays;
//10. Write a function to find the duplicate values of an array
public class Array_JA_10 {

    public static int[] removeElement(int[] array, int elementToRemove) {
        // Count the number of occurrences of the element to remove
        int count = 0;
        for (int value : array) {
            if (value == elementToRemove) {
                count++;
            }
        }

        // If the element is not found, return the original array
        if (count == 0) {
            return array;
        }

        // Create a new array with a size reduced by the number of occurrences of the element
        int[] newArray = new int[array.length - count];
        int index = 0;

        // Copy elements except the one to remove
        for (int value : array) {
            if (value != elementToRemove) {
                newArray[index++] = value;
            }
        }

        return newArray;
    }

    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 2, 5, 2};
        int elementToRemove = 2;

        int[] newArray = removeElement(array, elementToRemove);

        System.out.println("Array after removal:");
        System.out.println(Arrays.toString(newArray));
    }

}

	
