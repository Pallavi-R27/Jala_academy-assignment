package com.arrays;
//9. Write a function to reverse an array of integer values
public class Array_JA_09 {
	public static void reverseArray(int[] array) {
        if (array == null || array.length <= 1) {
            return; // No need to reverse if array is null or has 0 or 1 element
        }

        int left = 0;
        int right = array.length - 1;

        while (left < right) {
            // Swap the elements at left and right
            int temp = array[left];
            array[left] = array[right];
            array[right] = temp;

            // Move towards the middle
            left++;
            right--;
        }
    }

    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5};

        System.out.println("Original array:");
        for (int i : array) {
            System.out.print(i + " ");
        }
        System.out.println();

        reverseArray(array);

        System.out.println("Reversed array:");
        for (int i : array) {
            System.out.print(i + " ");
        }
    }
}


	