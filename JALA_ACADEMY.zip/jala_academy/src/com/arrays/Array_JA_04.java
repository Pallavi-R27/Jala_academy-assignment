package com.arrays;
//4. Write a function to test if array contains a specific value.
public class Array_JA_04 {

	public static void main(String[] args) {
		int [] elements= {11,22,33,44,55};
		int specific=11;
		int index=specific_value(elements,specific);
		if(index !=-1) {
			System.out.println("specific value "+specific+" of index:"+index);
			
		}else {
			System.out.println("Specific value does not contain:"+specific);
		}
		

	}
	private static int specific_value(int[] array,int ele) {
		for(int i=0;i<array.length;i++) {
			if(array[i]==ele) {
				return i;
			}
			
		}
	
		return -1;
	}

}
