package com.arrays;
//7.Write a function to insert an element at a specific position in the array.

public class Array_JA_07 {
	 public static int[] insertElement(int[] originalArray, int element, int position) {
	        int[] newArray = new int[originalArray.length + 1];

	        for (int i = 0; i < position; i++) {
	            newArray[i] = originalArray[i];
	        }

	        newArray[position] = element;

	        for (int i = position; i < originalArray.length; i++) {
	            newArray[i + 1] = originalArray[i];
	        }

	        return newArray;
	    }

	    public static void main(String[] args) {
	        int[] originalArray = {1, 2, 3, 4, 5};
	        int element = 99;
	        int position = 2;

	        int[] newArray = insertElement(originalArray, element, position);

	        for (int i : newArray) {
	            System.out.print(i + " ");
	        }
	    }
	}


	
	