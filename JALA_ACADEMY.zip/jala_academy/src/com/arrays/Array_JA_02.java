package com.arrays;
//2.Write a function to calculate the average value of an array of integers 

public class Array_JA_02 {
	public static double Averge_array(int[] array) {
		int sum=0;
		double fin=0;
		for(int i=1;i<array.length;i++) {
			sum=sum+array[i];
			fin= sum/array.length;
			
		}
		return fin;
		
	}

	public static void main(String[] args) {
		int[] numbers= {1,2,3,4,5,6};
		double result=Averge_array(numbers);
		System.out.println("The average of array is:"+result);
		
		}

}
