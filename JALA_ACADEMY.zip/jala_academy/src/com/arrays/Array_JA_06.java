package com.arrays;
//6. Write a function to copy an array to another array 

public class Array_JA_06 {

	public static void main(String[] args) {
		int[] sourceArray = {1, 2, 3, 4, 5};
		int[] destinationArray = new int[sourceArray.length];
		System.arraycopy(sourceArray, 0, destinationArray, 0, sourceArray.length);
			// Print the destination array to verify the copy
		     for (int i : destinationArray) {
		          System.out.print(i + " ");
		        }
		    }
		

		

	}


