package com.arrays;
//11. Write a program to find the common values between two arrays.
public class Array_JA_11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
