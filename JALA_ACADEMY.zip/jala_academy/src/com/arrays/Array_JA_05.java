package com.arrays;
import java.util.Arrays;
//5. Write a function to remove a specific element from an array

public class Array_JA_05 {
	public static int[] removeElement(int[] array, int elementToRemove) {
        // Count the number of occurrences of the element to remove
        int count = 0;
        for (int value : array) {
            if (value == elementToRemove) {
                count++;
            }
        }

        // If the element is not found, return the original array
        if (count == 0) {
            return array;
        }

        // Create a new array with a size reduced by the number of occurrences of the element
        int[] newArray = new int[array.length - count];
        int index = 0;

        // Copy elements except the one to remove
        for (int value : array) {
            if (value != elementToRemove) {
                newArray[index++] = value;
            }
        }

        return newArray;
    }

    public static void main(String[] args) {
        int[] array = {1, 9, 3, 4, 9, 5, 2};
        int elementToRemove = 9;

        int[] newArray = removeElement(array, elementToRemove);

        System.out.println("Array after removal:");
        System.out.println(Arrays.toString(newArray));
    }
}


	