package com.static5;
//5. Call static methods in instance methods
/* create an instance of the class first. This is because static 
 * methods belong to the class, whereas instance methods belong 
 * to an instance of the class./*
 */

public class Static_JA_05 {
	//creating static var
	static String staticvar="hello static!!";
	//creating instance var
	String instancevar="hey instance!!";
	//creating static method
		public static void method() {
			System.out.println("static variable:"+staticvar);
			
		}

	//creating instance method
	public void method2() {
		Static_JA_05.method();
		System.out.println("instance variable:"+instancevar);
	}
	
	public static void main(String[] args) {
		 // Creating an instance
		Static_JA_05 s1=new Static_JA_05();
		 // Calling the instance method to print variables
		s1.method2();
		
	}

}
