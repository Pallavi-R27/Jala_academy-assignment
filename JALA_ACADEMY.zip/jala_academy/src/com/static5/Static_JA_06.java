package com.static5;
//6. Print all the static, instance variables in main method


public class Static_JA_06 {
	//creating static variables.
	static int num=12;
	static String name="hey static";
	//creating instance variables.
	int num2=27;
	String name2="hey instance";

	public static void main(String[] args) {
		//accesing and printing static
		System.out.println("Accessing static:"+Static_JA_06.num);
		System.out.println("Accessing static:"+Static_JA_06.name);
		//accessing and printing instance
		Static_JA_06 s1=new Static_JA_06();
		System.out.println("Accessing instance:"+s1.num2);
		System.out.println("Accessing instance:"+s1.name2);
		

	}

}
