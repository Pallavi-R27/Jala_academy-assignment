package com.static5;
//7.Call static methods and instance methods in main method 

public class Static_JA_07 {
	//creating static variables
	static int num=22;
	static String name="static!!";
	//creating instance variables
	int num2=55;
	String name2="instance!!";
	//creating static method
	public static void method() {
		System.out.println("calling static in main method:"+num);
		System.out.println("calling static in main method:"+name);
	}
	//creating instance method
	public void method2() {
		System.out.println("calling static in main method:"+num2);
		System.out.println("calling instance in main method:"+name2);
		
	}

	public static void main(String[] args) {
		//calling static method
		Static_JA_07.method();
	
		Static_JA_07 s2=new Static_JA_07();
		s2.method2();

	}

}
