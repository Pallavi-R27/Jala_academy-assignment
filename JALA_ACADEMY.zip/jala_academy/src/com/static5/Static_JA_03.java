package com.static5;
//3. Print static variables in Instance methods.
/*instance methods can directly access both static and instance variables 
 because instance methods are associated with an object of the class, but 
 they have access to the class-level static variables as well.
 */

public class Static_JA_03 {
	//creating static variable
	static String staticvar="it is a static!!";
	//creating instance variable
	static String instancevar="it is a instance";
	
	// Instance method to print variables
    public void printVariables() {
    	System.out.println("static variable:"+staticvar);
    	System.out.println("instance variable:"+instancevar);
    	
    }
	
	    public static void main(String[] args) {
	    	//creating a instance object
	    	 Static_JA_03 s1=new  Static_JA_03();
	    	 //calling the method printvariables
	    	 s1.printVariables();
	    	
	       
	    	
	    }
	}



