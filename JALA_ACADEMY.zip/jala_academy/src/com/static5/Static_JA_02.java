package com.static5;
//2.Print instance variables in static methods.
/*static methods belong to the class itself rather than any particular 
  instance, so they cannot directly access instance variables because 
  instance variables are tied to a specific object. However, you can access 
  instance variables within a static method by creating an instance of the class
 */

public class Static_JA_02 {
	//creating static variables.
	static int num=12;
	static String name="virat";
	
	//instance variables.
	int num1=27;
	String word="Dhoni";
	public static void staticMethod1() {
      // Creating an instance of the class to access instance variables
		Static_JA_02 a1= new Static_JA_02();
		System.out.println("Hello static method!!");
        System.out.println("Static variable: " + a1.num);
        System.out.println("Static variable: " + a1.name);
    }
	 public static void staticMethod2() {
	 // Creating an instance of the class to access instance variables
		 Static_JA_02 a2 = new Static_JA_02 ();
	  System.out.println("Hello Static Method2!!");
	  System.out.println("InstanceVar1: " + a2.num1);
	  System.out.println("InstanceVar2: " + a2.word);
	    }
	

	public static void main(String[] args) {
		 // Accessing static methods
        staticMethod1();
        staticMethod2();
	

	}

}
