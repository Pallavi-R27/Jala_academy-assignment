package com.static5;
//4. Call instance methods in static methods
/*you need to create an instance of the class first. This is because 
static methods belong to the class, whereas instance methods belong 
to an instance of the class.*/

public class Static_JA_04 {
	//creating static variable
	static String staticvar="hello static!!";
	//creating instance varibale;
	String instancevar="hello instance";
	//creating instance method
	public void instance1(){
		//accessing static variable directly
		System.out.println("static varaible:"+staticvar);
		//printing instance variable
		System.out.println("instance variable:"+instancevar);
	}
	//creating static method
	public static void callinginstance() {
		Static_JA_04  s1=new Static_JA_04();
		s1.instance1();
	}

	public static void main(String[] args) {
		 callinginstance();
		

	}

}
