package com.static5;
//1. Write a class with 2 static variables, 2 Instance variables, 
//2 static methods, 2 instance methods and a main method.

public class Static_JA_01 {
	//creating static varibales
	static int num =12;
	static String name="Tom";
	//creating static methods.
	public static void method1() {
		System.out.println("Hello static method1 !!");
		System.out.println("static num: "+num);
		}
	//creating static method2
	public static void method2() {
		System.out.println("Hello static method2!!");
		System.out.println("static name: "+name);
	}
	//creating instance variables
	int num1;
	String name1;
	//creating instance method
	public void method3(){
		System.out.println("Hello Instance method1!!");
	}
	//creating instance method2
	{
		System.out.println("Hello instance method2!!");
	}
	 
	 public static void main(String[] args) {
		//accessing static varibales
		System.out.println("Accessing static members!!");
		System.out.println("Static variable num: "+Static_JA_01.num);
		System.out.println("Static variable num: "+Static_JA_01.name);
		//accessing static method1
		Static_JA_01.method1();
		//accessing static method1
		Static_JA_01.method2();
		System.out.println("Accessing instance variables!!!");
		//creating a object
		Static_JA_01 s1=new Static_JA_01();
		s1.num1=13;
		s1.name1="jersey";
		System.out.println("instance variable num: "+s1.num1);
		System.out.println("instance variable num: "+s1.name1);
		s1.method3();
		
		
		
		
		

	}

}
