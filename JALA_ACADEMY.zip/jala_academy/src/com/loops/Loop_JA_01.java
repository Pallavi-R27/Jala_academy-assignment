package com.loops;
//1.Write a program to print  “Bright IT Career”  ten times using for loop. 

public class Loop_JA_01 {

	public static void main(String[] args) {
		for(int i=1;i<=10;i++) {
			System.out.println("Bright IT Career");
		}
		
		

	}

}
