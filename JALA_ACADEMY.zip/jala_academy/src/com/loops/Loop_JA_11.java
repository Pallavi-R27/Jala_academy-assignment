package com.loops;
//11. Program to check whether a number is EVEN or ODD using switch.
//insteat of writing many if else you can use the switch statement.
//The switch expression is evaluated once.
//The value of the expression is compared with the values of each case.
//If there is a match, the associated block of code is executed.
//The break and default keywords are optional

public class Loop_JA_11 {

	public static void main(String[] args) {
		int num=10;
		switch(num%2) {
		case 0:
			System.out.println(num+" EVEN_NUMBER");
			break;
		
		case 1:
			System.out.println(num+ " ODD_NUMBER");
			break;
		default:
			System.out.println("INVALID INPUT");
		}

		}
		

	}


