package com.loops;
//13. Program for multiple if else statement(Largest number  in 10,20 and 30) 

public class Loop_JA_13 {

	public static void main(String[] args) {
		int a=10;
		int b=20;
		int c=30;
		if(a>b && a>c) {
			System.out.println("Largest Number: "+a);
		}else if(b>a && b>c) {
			System.out.println("Largest Number: "+b);
		}else {
			System.out.println("Largest Number: "+c);
		}
	

	}

}
