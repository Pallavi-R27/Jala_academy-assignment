package com.loops;
//2. Write a java program to print 1 to 20 numbers using the while loop. 

public class Loop_JA_02 {

	public static void main(String[] args) {
		int number = 1; // Initialize the starting number

        // Use while loop to print numbers from 1 to 20
        while (number <= 20) {
            System.out.println(number);
            number++; // Increment the number by 1
        }
		
		
		

	}

}
