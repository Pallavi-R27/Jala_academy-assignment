package com.loops;
//12. Print gender (Male/Female) program according to given M/F using switch

public class Loop_JA_12 {

	public static void main(String[] args) {
		char gender='F';
		switch(gender) {
		case 'M':
			System.out.println("Gender:Male");
			break;
		case 'F':
			System.out.println("Gender:Female");
			break;
		default:
			System.out.println("invalid input! please enter M for male or F for female");
		}
		

	}

}
