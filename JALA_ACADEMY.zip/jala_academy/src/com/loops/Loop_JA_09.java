package com.loops;
import java.util.Scanner;
//9. Write a program to find the prime or not.

public class Loop_JA_09 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number: ");
		int num=sc.nextInt();
		int count=0;
		for(int i=1;i<=num;i++) {
			if(num%i==0) {
				count=count+1;
			}
		}
		if(count==2) {
			System.out.println("Prime Number");
		}else {
			System.out.println("Not a Prime Number");
		}
		
		

	}

}
