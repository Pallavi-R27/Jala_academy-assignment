package com.loops;
//4. Write a program to print the odd and even numbers.
import java.util.Scanner;

public class Loop_JA_04 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number: ");
		int num=sc.nextInt();
		if(num%2==0) {
			System.out.println("even_number");
		}else {
			System.out.println("Odd number");
		}
		sc.close();
		
		

	}

}
