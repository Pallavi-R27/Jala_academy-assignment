package com.loops;
//7. Write a program to print 1 to 10 using the do-while loop statement.
public class Loop_JA_07 {

	public static void main(String[] args) {
		int number=1;
		do {
			System.out.println(number);
			number++;
		}while(number<=10);
		
		

	}

}
