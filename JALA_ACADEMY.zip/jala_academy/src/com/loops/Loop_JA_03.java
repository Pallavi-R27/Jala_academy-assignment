package com.loops;
import java.util.Scanner;
//3. Program to equal operator and not equal operators.

public class Loop_JA_03 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the first number: ");
		int num=sc.nextInt();
		System.out.println("enter the second number: ");
		int num1=sc.nextInt();
		
		if(num==num1) {
			System.out.println("numbers are equal");
		}else if(num != num1){
			System.out.println("numbers are not equal");
		}
		sc.close();
		
		
		

	}

}
