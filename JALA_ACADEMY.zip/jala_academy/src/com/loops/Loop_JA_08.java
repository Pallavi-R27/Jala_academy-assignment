package com.loops;
//8. Write a program to find Armstrong number or not 

public class Loop_JA_08 {

	public static void main(String[] args) {
		int num=153;
		int temp=num;
		int res=0;
		while(temp>0) {
		int id=temp%10;
		res=res+id*id*id;
		temp=temp/10;
		}
		if(num==res) {
			System.out.println("Armstrong number");
		}
		else {
			System.out.println("Not a Armstrong number");
		}
		
		
		

	}

}
